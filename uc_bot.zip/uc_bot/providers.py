"""UC yetkazib beruvchi (provayder) adapterlari.

Bot shu fayldagi `get_provider()` orqali ishlaydi. Provayder almashsa, faqat shu
fayl o'zgaradi, bot.py ga tegilmaydi.

Muhim qoida: pul/UC bilan bog'liq so'rov taymaut yoki 5xx xato bilan tugasa,
natija NOMA'LUM ("unknown") deb olinadi va avtomatik QAYTA YUBORILMAYDI.
Aks holda mijozga UC ikki marta tushib ketishi mumkin. Bunday buyurtmani admin
provayder kabinetidan qo'lda tekshiradi.
"""

import asyncio
import logging
import os
from dataclasses import dataclass

import httpx

log = logging.getLogger("providers")


@dataclass
class DeliveryResult:
    status: str  # "ok" | "failed" | "unknown"
    ref: str = ""
    error: str = ""


class Provider:
    name = "base"

    async def deliver(self, order_id: int, player_id: str, uc: int) -> DeliveryResult:
        raise NotImplementedError

    async def balance(self):
        """Provayderdagi qoldiq. Qo'llab-quvvatlanmasa None qaytaradi."""
        return None


class MockProvider(Provider):
    """Sinov uchun: haqiqiy UC yuborilmaydi, har doim muvaffaqiyatli deydi."""

    name = "mock"

    async def deliver(self, order_id: int, player_id: str, uc: int) -> DeliveryResult:
        await asyncio.sleep(1)
        log.info("MOCK: order=%s player=%s uc=%s", order_id, player_id, uc)
        return DeliveryResult("ok", ref=f"MOCK-{order_id}")

    async def balance(self):
        return "mock (cheksiz)"


class HttpProvider(Provider):
    """Umumiy HTTP provayder shabloni.

    DIQQAT: haqiqiy provayderlarning API'si har xil. Provayder hujjatini olgach,
    quyidagi ikkita joyni moslang:
      1) build_payload()     - so'rov tanasi (maydon nomlari)
      2) parse_response()    - javobni ok / failed / unknown ga ajratish
    URL va kalit esa Railway o'zgaruvchilaridan olinadi.
    """

    name = "http"

    def __init__(self) -> None:
        self.url = os.environ["PROVIDER_URL"]
        self.key = os.environ["PROVIDER_KEY"]
        self.balance_url = os.getenv("PROVIDER_BALANCE_URL", "")
        self.auth_header = os.getenv("PROVIDER_AUTH_HEADER", "Authorization")
        self.auth_prefix = os.getenv("PROVIDER_AUTH_PREFIX", "Bearer ")
        self.timeout = float(os.getenv("PROVIDER_TIMEOUT", "30"))

    def _headers(self) -> dict:
        return {self.auth_header: f"{self.auth_prefix}{self.key}"}

    def build_payload(self, order_id: int, player_id: str, uc: int) -> dict:
        # `reference` bizning buyurtma raqamimiz: provayder takroriy so'rovni
        # shu bo'yicha ajratishi kerak (idempotentlik).
        return {"reference": str(order_id), "player_id": player_id, "uc": uc}

    def parse_response(self, resp: httpx.Response) -> DeliveryResult:
        code = resp.status_code
        try:
            data = resp.json()
        except Exception:
            data = {}
        if not isinstance(data, dict):
            data = {}

        if 200 <= code < 300:
            status = str(data.get("status", "")).lower()
            if data.get("success") is True or status in ("ok", "success", "completed", "done"):
                ref = str(data.get("id") or data.get("order_id") or data.get("transaction_id") or "")
                return DeliveryResult("ok", ref=ref)
            if status in ("pending", "processing", "queued"):
                return DeliveryResult("unknown", error=f"provayder holati: {status}")
            return DeliveryResult("failed", error=str(data.get("message") or data.get("error") or resp.text[:200]))
        if code == 408 or code >= 500:
            return DeliveryResult("unknown", error=f"HTTP {code}")
        return DeliveryResult("failed", error=str(data.get("message") or data.get("error") or f"HTTP {code}"))

    async def deliver(self, order_id: int, player_id: str, uc: int) -> DeliveryResult:
        payload = self.build_payload(order_id, player_id, uc)
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self.url, json=payload, headers=self._headers())
        except Exception as exc:  # taymaut, tarmoq xatosi: natija noma'lum
            log.exception("provider request failed")
            return DeliveryResult("unknown", error=f"{type(exc).__name__}: {exc}")
        log.info("provider response order=%s http=%s", order_id, resp.status_code)
        return self.parse_response(resp)

    async def balance(self):
        if not self.balance_url:
            return None
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.get(self.balance_url, headers=self._headers())
            data = resp.json()
            if isinstance(data, dict):
                return data.get("balance", data)
            return data
        except Exception as exc:
            return f"xato: {exc}"


def get_provider() -> Provider:
    name = os.getenv("PROVIDER", "mock").strip().lower()
    if name == "mock":
        return MockProvider()
    if name == "http":
        return HttpProvider()
    raise RuntimeError(f"Noma'lum PROVIDER={name!r}. 'mock' yoki 'http' ishlating.")
