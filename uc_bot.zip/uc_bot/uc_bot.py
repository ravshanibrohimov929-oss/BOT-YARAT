"""PUBG Mobile UC sotuvchi Telegram bot.

Oqim: paket tanlash -> PUBG ID -> ID tasdig'i -> to'lov + chek rasmi ->
admin "Tasdiqlash" bosadi -> UC provayder orqali AVTOMATIK yetkaziladi.
"""

import asyncio
import html
import logging
import os
import re
import sqlite3
import threading
import time

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import CallbackQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from providers import get_provider

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("uc_bot")

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
ADMIN_IDS = {
    int(x) for x in re.split(r"[,\s]+", os.getenv("ADMIN_IDS", "")) if x.strip().isdigit()
}
PAYMENT_INFO = os.getenv(
    "PAYMENT_INFO", "To'lov rekvizitlari kiritilmagan. Admin bilan bog'laning."
)
SUPPORT_CONTACT = os.getenv("SUPPORT_CONTACT", "")
DB_PATH = os.getenv("DB_PATH", "uc_bot.db")

# Standart paketlar. NARXLAR FAQAT NAMUNA: /setprice buyrug'i bilan o'zgartiring.
DEFAULT_PACKAGES = [
    (60, 13000),
    (325, 65000),
    (660, 130000),
    (1800, 325000),
    (3850, 650000),
    (8100, 1300000),
]


# ----------------------------------------------------------------- baza
class DB:
    def __init__(self, path: str) -> None:
        folder = os.path.dirname(path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        self._init()

    def _init(self) -> None:
        with self.lock:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS packages (
                    uc INTEGER PRIMARY KEY,
                    price INTEGER NOT NULL,
                    active INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    username TEXT,
                    player_id TEXT NOT NULL,
                    uc INTEGER NOT NULL,
                    price INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    receipt_file_id TEXT,
                    provider_ref TEXT,
                    error TEXT,
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL
                );
                """
            )
            if not self.conn.execute("SELECT 1 FROM packages LIMIT 1").fetchone():
                self.conn.executemany(
                    "INSERT INTO packages (uc, price) VALUES (?, ?)", DEFAULT_PACKAGES
                )
            self.conn.commit()

    def execute(self, sql: str, params: tuple = ()):
        with self.lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur.rowcount, cur.lastrowid

    def query(self, sql: str, params: tuple = ()):
        with self.lock:
            return self.conn.execute(sql, params).fetchall()

    def one(self, sql: str, params: tuple = ()):
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def claim(self, order_id: int, from_status: str, to_status: str) -> bool:
        """Holatni atomik o'zgartiradi. Ikki marta bosilishdan himoya qiladi."""
        rowcount, _ = self.execute(
            "UPDATE orders SET status=?, updated_at=? WHERE id=? AND status=?",
            (to_status, int(time.time()), order_id, from_status),
        )
        return rowcount == 1

    def set_status(self, order_id: int, status: str, ref: str = "", error: str = "") -> None:
        self.execute(
            "UPDATE orders SET status=?, provider_ref=?, error=?, updated_at=? WHERE id=?",
            (status, ref, error, int(time.time()), order_id),
        )


db = DB(DB_PATH)
provider = get_provider()
dp = Dispatcher(storage=MemoryStorage())


# ----------------------------------------------------------- yordamchilar
def fmt(n: int) -> str:
    return f"{n:,}".replace(",", " ")


def esc(s) -> str:
    return html.escape(str(s or ""))


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def packages_kb():
    kb = InlineKeyboardBuilder()
    for p in db.query("SELECT uc, price FROM packages WHERE active=1 ORDER BY uc"):
        kb.button(text=f"{p['uc']} UC — {fmt(p['price'])} so'm", callback_data=f"buy:{p['uc']}")
    kb.adjust(1)
    return kb.as_markup()


def admin_kb(order_id: int):
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Tasdiqlash", callback_data=f"ok:{order_id}")
    kb.button(text="❌ Rad etish", callback_data=f"no:{order_id}")
    kb.adjust(2)
    return kb.as_markup()


def order_caption(o) -> str:
    who = f"@{esc(o['username'])}" if o["username"] else f"id {o['user_id']}"
    return (
        f"🧾 <b>Buyurtma #{o['id']}</b>\n"
        f"👤 {who}\n"
        f"🎮 PUBG ID: <code>{esc(o['player_id'])}</code>\n"
        f"💎 {o['uc']} UC\n"
        f"💰 {fmt(o['price'])} so'm"
    )


async def notify_admins(bot: Bot, text: str) -> None:
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, text)
        except Exception:
            log.exception("admin %s ga yuborib bo'lmadi", admin_id)


async def safe_send(bot: Bot, chat_id: int, text: str) -> None:
    try:
        await bot.send_message(chat_id, text)
    except Exception:
        log.exception("%s ga xabar yuborib bo'lmadi", chat_id)


async def edit_admin_msg(call: CallbackQuery, extra: str) -> None:
    """Admin xabarini yangilaydi (rasmli xabarda caption, aks holda matn)."""
    try:
        base = call.message.html_text if call.message.text else (call.message.caption or "")
        if call.message.photo:
            await call.message.edit_caption(caption=f"{base}\n\n{extra}", reply_markup=None)
        else:
            await call.message.edit_text(f"{base}\n\n{extra}", reply_markup=None)
    except Exception:
        log.exception("admin xabarini tahrirlab bo'lmadi")


class Order(StatesGroup):
    player_id = State()
    confirm = State()
    receipt = State()


# ------------------------------------------------------------ mijoz oqimi
@dp.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "👋 Salom! PUBG Mobile UC xarid qilish botiga xush kelibsiz.\n\n"
        "Kerakli paketni tanlang:",
        reply_markup=packages_kb(),
    )


@dp.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    order_id = data.get("order_id")
    if order_id:
        db.claim(order_id, "awaiting_receipt", "cancelled")
    await state.clear()
    await message.answer("Bekor qilindi. Qayta boshlash uchun /start bosing.")


@dp.callback_query(F.data.startswith("buy:"))
async def cb_buy(call: CallbackQuery, state: FSMContext) -> None:
    uc = int(call.data.split(":")[1])
    pkg = db.one("SELECT uc, price FROM packages WHERE uc=? AND active=1", (uc,))
    if not pkg:
        await call.answer("Bu paket hozir mavjud emas.", show_alert=True)
        return
    await state.set_state(Order.player_id)
    await state.update_data(uc=pkg["uc"], price=pkg["price"])
    await call.message.answer(
        f"💎 <b>{pkg['uc']} UC</b> — {fmt(pkg['price'])} so'm\n\n"
        "PUBG Mobile <b>ID raqamingizni</b> yuboring (faqat raqamlar).\n"
        "Bekor qilish: /cancel"
    )
    await call.answer()


@dp.message(Order.player_id, F.text)
async def on_player_id(message: Message, state: FSMContext) -> None:
    player_id = message.text.strip()
    if not re.fullmatch(r"\d{5,12}", player_id):
        await message.answer("ID faqat raqamlardan iborat bo'lishi kerak (5–12 ta raqam). Qayta yuboring.")
        return
    await state.update_data(player_id=player_id)
    await state.set_state(Order.confirm)
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Ha, to'g'ri", callback_data="idok")
    kb.button(text="✏️ Boshqa ID", callback_data="idno")
    kb.adjust(2)
    await message.answer(
        f"PUBG ID: <code>{esc(player_id)}</code>\n\n"
        "⚠️ UC noto'g'ri ID'ga tushsa, qaytarib bo'lmaydi. ID to'g'rimi?",
        reply_markup=kb.as_markup(),
    )


@dp.callback_query(Order.confirm, F.data == "idno")
async def cb_id_wrong(call: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(Order.player_id)
    await call.message.answer("To'g'ri PUBG ID raqamini yuboring:")
    await call.answer()


@dp.callback_query(Order.confirm, F.data == "idok")
async def cb_id_ok(call: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    now = int(time.time())
    _, order_id = db.execute(
        "INSERT INTO orders (user_id, username, player_id, uc, price, status, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, ?, 'awaiting_receipt', ?, ?)",
        (
            call.from_user.id,
            call.from_user.username,
            data["player_id"],
            data["uc"],
            data["price"],
            now,
            now,
        ),
    )
    await state.set_state(Order.receipt)
    await state.update_data(order_id=order_id)
    await call.message.answer(
        f"🧾 <b>Buyurtma #{order_id}</b>\n"
        f"💎 {data['uc']} UC\n"
        f"🎮 ID: <code>{esc(data['player_id'])}</code>\n"
        f"💰 To'lov summasi: <b>{fmt(data['price'])} so'm</b>\n\n"
        f"{esc(PAYMENT_INFO)}\n\n"
        "To'lovni amalga oshirib, <b>chek rasmini (skrinshot)</b> shu yerga yuboring.\n"
        "Bekor qilish: /cancel"
    )
    await call.answer()


@dp.message(Order.receipt, F.photo)
async def on_receipt(message: Message, state: FSMContext, bot: Bot) -> None:
    data = await state.get_data()
    order_id = data.get("order_id")
    file_id = message.photo[-1].file_id
    if not order_id or not db.claim(order_id, "awaiting_receipt", "pending_review"):
        await message.answer("Bu buyurtma allaqachon qabul qilingan yoki bekor qilingan. /start")
        await state.clear()
        return
    db.execute("UPDATE orders SET receipt_file_id=? WHERE id=?", (file_id, order_id))
    order = db.one("SELECT * FROM orders WHERE id=?", (order_id,))
    await state.clear()
    await message.answer(
        f"✅ Chek qabul qilindi. Buyurtma #{order_id} tekshirilmoqda.\n"
        "Tasdiqlangach UC avtomatik tushadi, sizga xabar beraman."
    )
    if not ADMIN_IDS:
        log.warning("ADMIN_IDS bo'sh: buyurtma #%s tasdiqlanmaydi!", order_id)
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_photo(
                admin_id, file_id, caption=order_caption(order), reply_markup=admin_kb(order_id)
            )
        except Exception:
            log.exception("admin %s ga chek yuborib bo'lmadi", admin_id)


@dp.message(Order.receipt)
async def on_receipt_wrong(message: Message) -> None:
    await message.answer("Iltimos, to'lov chekini <b>rasm</b> ko'rinishida yuboring. Bekor qilish: /cancel")


# ------------------------------------------------------------ admin tugmalari
@dp.callback_query(F.data.startswith("no:"))
async def cb_reject(call: CallbackQuery, bot: Bot) -> None:
    if not is_admin(call.from_user.id):
        await call.answer("Ruxsat yo'q.", show_alert=True)
        return
    order_id = int(call.data.split(":")[1])
    if not db.claim(order_id, "pending_review", "rejected"):
        await call.answer("Bu buyurtma allaqachon ko'rib chiqilgan.", show_alert=True)
        return
    order = db.one("SELECT * FROM orders WHERE id=?", (order_id,))
    await edit_admin_msg(call, f"❌ Rad etildi ({esc(call.from_user.full_name)})")
    contact = f"\nSavollar uchun: {esc(SUPPORT_CONTACT)}" if SUPPORT_CONTACT else ""
    await safe_send(
        bot,
        order["user_id"],
        f"❌ Buyurtma #{order_id} rad etildi: to'lov tasdiqlanmadi.{contact}",
    )
    await call.answer()


@dp.callback_query(F.data.startswith("ok:"))
async def cb_approve(call: CallbackQuery, bot: Bot) -> None:
    if not is_admin(call.from_user.id):
        await call.answer("Ruxsat yo'q.", show_alert=True)
        return
    order_id = int(call.data.split(":")[1])
    if not db.claim(order_id, "pending_review", "processing"):
        await call.answer("Bu buyurtma allaqachon ko'rib chiqilgan.", show_alert=True)
        return
    await call.answer("UC yuborilmoqda...")
    order = db.one("SELECT * FROM orders WHERE id=?", (order_id,))
    await edit_admin_msg(call, "⏳ UC yetkazilmoqda...")

    result = await provider.deliver(order_id, order["player_id"], order["uc"])
    contact = f"\nSavollar uchun: {esc(SUPPORT_CONTACT)}" if SUPPORT_CONTACT else ""

    if result.status == "ok":
        db.set_status(order_id, "delivered", ref=result.ref)
        await edit_admin_msg(call, f"✅ Yetkazildi (ref: {esc(result.ref) or '-'})")
        await safe_send(
            bot,
            order["user_id"],
            f"🎉 Buyurtma #{order_id}: <b>{order['uc']} UC</b> hisobingizga yuborildi!\n"
            "O'yinni ochib tekshiring. Rahmat!",
        )
    elif result.status == "failed":
        db.set_status(order_id, "failed", error=result.error)
        await edit_admin_msg(
            call, f"⚠️ Provayder rad etdi: {esc(result.error)}\nPulni mijozga qaytarish kerak."
        )
        await safe_send(
            bot,
            order["user_id"],
            f"⚠️ Buyurtma #{order_id} bo'yicha UC yuborib bo'lmadi. "
            f"Administrator siz bilan bog'lanadi.{contact}",
        )
    else:  # unknown
        db.set_status(order_id, "unknown", error=result.error)
        await edit_admin_msg(
            call,
            f"❓ Natija noma'lum: {esc(result.error)}\n"
            "UC tushgan bo'lishi mumkin. Provayder kabinetida QO'LDA tekshiring, qayta yubormang.",
        )
        await safe_send(
            bot,
            order["user_id"],
            f"⏳ Buyurtma #{order_id} tekshirilmoqda. Tez orada xabar beramiz.{contact}",
        )


# -------------------------------------------------------- admin buyruqlari
@dp.message(Command("stats"))
async def cmd_stats(message: Message) -> None:
    if not is_admin(message.from_user.id):
        return
    rows = db.query("SELECT status, COUNT(*) AS n, COALESCE(SUM(price),0) AS s FROM orders GROUP BY status")
    if not rows:
        await message.answer("Hali buyurtmalar yo'q.")
        return
    lines = [f"{r['status']}: {r['n']} ta, {fmt(r['s'])} so'm" for r in rows]
    await message.answer("📊 <b>Statistika</b>\n" + "\n".join(lines))


@dp.message(Command("orders"))
async def cmd_orders(message: Message) -> None:
    if not is_admin(message.from_user.id):
        return
    rows = db.query("SELECT * FROM orders ORDER BY id DESC LIMIT 10")
    if not rows:
        await message.answer("Hali buyurtmalar yo'q.")
        return
    lines = [
        f"#{r['id']} · {r['uc']} UC · <code>{esc(r['player_id'])}</code> · {r['status']}" for r in rows
    ]
    await message.answer("🗂 <b>Oxirgi 10 ta buyurtma</b>\n" + "\n".join(lines))


@dp.message(Command("setprice"))
async def cmd_setprice(message: Message) -> None:
    """/setprice 325 65000. Narx 0 bo'lsa, paket o'chiriladi."""
    if not is_admin(message.from_user.id):
        return
    parts = (message.text or "").split()
    if len(parts) != 3 or not parts[1].isdigit() or not parts[2].isdigit():
        await message.answer("Format: <code>/setprice 325 65000</code> (narx 0 bo'lsa paket o'chadi)")
        return
    uc, price = int(parts[1]), int(parts[2])
    if price == 0:
        db.execute("UPDATE packages SET active=0 WHERE uc=?", (uc,))
        await message.answer(f"{uc} UC paketi o'chirildi.")
        return
    db.execute(
        "INSERT INTO packages (uc, price, active) VALUES (?, ?, 1) "
        "ON CONFLICT(uc) DO UPDATE SET price=excluded.price, active=1",
        (uc, price),
    )
    await message.answer(f"✅ {uc} UC = {fmt(price)} so'm")


@dp.message(Command("balance"))
async def cmd_balance(message: Message) -> None:
    if not is_admin(message.from_user.id):
        return
    bal = await provider.balance()
    await message.answer(f"💳 Provayder ({provider.name}) qoldig'i: {esc(bal) if bal is not None else 'noma`lum'}")


@dp.message(F.text)
async def fallback(message: Message) -> None:
    await message.answer("Buyurtma berish uchun /start bosing.")


# ---------------------------------------------------------------- ishga tushirish
async def main() -> None:
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN o'rnatilmagan.")
    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))

    # Bot o'chib qolganda "processing" holatida qolgan buyurtmalar: natija noma'lum.
    stuck = db.query("SELECT id FROM orders WHERE status='processing'")
    for r in stuck:
        db.set_status(r["id"], "unknown", error="bot yetkazish paytida to'xtagan")
    if stuck:
        ids = ", ".join(f"#{r['id']}" for r in stuck)
        await notify_admins(
            bot, f"⚠️ Bot qayta ishga tushdi. Natijasi noma'lum buyurtmalar: {ids}. Provayderda qo'lda tekshiring."
        )

    log.info("Bot ishga tushdi. Provayder=%s, adminlar=%s", provider.name, sorted(ADMIN_IDS))
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
