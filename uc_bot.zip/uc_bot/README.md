# PUBG UC Bot

Telegram orqali PUBG Mobile UC sotadigan bot. Alohida loyiha: eski `bot.py` ga tegilmaydi.

## Qanday ishlaydi

1. Mijoz paketni tanlaydi (60, 325, 660, 1800, 3850, 8100 UC).
2. PUBG ID kiritadi va to'g'riligini tasdiqlaydi.
3. Bot to'lov rekvizitlarini beradi, mijoz chek rasmini yuboradi.
4. Adminga chek va **Tasdiqlash / Rad etish** tugmalari boradi.
5. Admin tasdiqlasa, **UC avtomatik yetkaziladi** (provayder API orqali) va mijozga xabar boradi.

> Muhim: to'lovni admin ko'zi bilan tasdiqlaydi (bir tugma). To'lovni ham to'liq
> avtomatik qilish uchun Payme/Click kabi to'lov tizimi bilan merchant shartnoma kerak,
> bu keyingi bosqich.

## Midasbuy haqida

Midasbuy'ning rasmiy ochiq API'si yo'q, unga bot orqali ulanib bo'lmaydi.
UC'ni avtomatik berish uchun **UC yetkazib beruvchi (distribyutor)** xizmatining API'si kerak.

## API kalitni qanday olish (klient uchun)

1. UC yetkazib beruvchi xizmatni tanlang (bir nechta xizmat solishtiring: narx, ishonchlilik,
   to'lov usuli, API hujjati borligi, kafolat).
2. U yerda reseller (sotuvchi) akkaunt oching va hisobingizni pul bilan to'ldiring.
3. Kabinetda **API / Developer** bo'limidan kalit (token) va API hujjatini oling.
4. Kalitni faqat Railway Variables'ga qo'ying. GitHub'ga yoki chatga yozmang.

Hujjatni olgach, `providers.py` dagi `build_payload()` va `parse_response()` ni
provayderning maydon nomlariga moslang. Bu kichik o'zgarish.

## Railway'ga joylash

1. Bu papkani yangi GitHub repoga yuklang.
2. Railway: **New Project > Deploy from GitHub repo**.
3. **Variables** bo'limiga `.env.example` dagi qiymatlarni kiriting.
4. **Volume** qo'shib `/data` ga ulang va `DB_PATH=/data/uc_bot.db` qo'ying.
   Volume bo'lmasa, har qayta deploy'da buyurtmalar bazasi o'chib ketadi.
5. Avval `PROVIDER=mock` bilan sinang: UC yuborilmaydi, butun oqim tekshiriladi.
6. Hammasi ishlagach `PROVIDER=http` va provayder kalitini qo'ying.

Railway'da faqat **bitta** nusxa ishlashi kerak (bir token bilan ikkita bot ishlasa, to'qnashadi).

## Admin buyruqlari

| Buyruq | Vazifa |
| --- | --- |
| `/stats` | Holatlar bo'yicha statistika |
| `/orders` | Oxirgi 10 buyurtma |
| `/setprice 325 65000` | Narxni o'zgartirish yoki paket qo'shish (narx 0 = o'chirish) |
| `/balance` | Provayderdagi qoldiq |

Standart narxlar **namuna**. Ishga tushirishdan oldin `/setprice` bilan haqiqiy narxlarni qo'ying.

## Xavfsizlik qoidalari (kodga kiritilgan)

- Admin ikki marta bossa ham, UC faqat **bir marta** yuboriladi.
- Provayder javobi noma'lum bo'lsa (taymaut, 5xx), buyurtma `unknown` bo'ladi va **qayta yuborilmaydi**:
  admin kabinetdan qo'lda tekshiradi. Bu UC'ning ikki marta tushishini oldini oladi.
- Bot yetkazish paytida o'chib qolsa, shunday buyurtmalar ham `unknown` bo'ladi va adminga xabar boradi.
- Noto'g'ri ID'ga UC ketmasligi uchun ID tasdig'i so'raladi.
